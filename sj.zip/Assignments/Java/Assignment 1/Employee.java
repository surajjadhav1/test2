class Employee{
	private int	eid;
	private int 	age;
	private int 	hours;
	private double 	rate;

	public Employee(){
		eid = 1001;
		age = 25;
		hours = 180;
		rate = 100.00;
	}
	public Employee(int id, int ag,int hrs,double r){
		eid   = id;
		age   = ag;
		hours = hrs;
		rate  = r;
	}

       public double getNetIncome(){
		int overtime = hours - 180;
		if (overtime>0)
			return hours * rate + overtime;
		else
			return hours * rate;
       }

       public void printEmployee(){
	       System.out.printf("The Employee with id %d is of age %d has worked %d hours %nThe netincome of concerned employee is %.2f",eid,age,hours,getNetIncome());
       } 
}
