package Series;

   final class Powersequence extends sequence implements Resetable{
     
             private double factor;

	     public Powersequence(){
		      current = 1;
		      factor  = 2;
	      }

             public double next(){
	         double term = current;
                  current* = factor;
                  return term;		    

	      }
	     public void reset(){  
		       current = 1;

               }


	      }
