package Series;


     public interface Restable{
	    void Reset(); 
    }



