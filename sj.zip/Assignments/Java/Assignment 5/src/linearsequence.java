package Series;

 final class  linearsequence extends sequence{
        
	 private double step;
       
	public linearsequence(){
	       current = 4;
                step   = 2;
           }

       public double next(){
              double term = current;
                 current += step;
	         return term;
	  }	 

 }
