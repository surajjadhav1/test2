package Series.*;


 class mainseries {
         
	 public double compute(sequence xy , int count){ 

         //  auto rc= dynamic_cast<Restable >(xy);
	   if (rs instanceof Resetable r){
		   r.Reset();
	   }
	 return xy.Sum(count)/count;
	 }

	 public static void main(String[]args)

          {
		   sequence rec = object.linear();
		   sequence prs = object.power();

	    System.out.printf("Linear sequence Average calculated = %lf\n",compute(rec,5));

	    System.out.printf("Power sequence Average calculated = %lf\n",compute(prs,5));
           

	  }
 }
