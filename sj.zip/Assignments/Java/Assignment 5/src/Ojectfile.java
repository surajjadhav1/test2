package Series;

   public class object{


	   public static sequence linear()
	     
	       {
		    linearsequence rec = new linearsequence()
		    return rec;	    

               }

	   public static sequence power()
	     
	      {
	          
	           powersequence pow = new powersequence();
                   return pow;
              }

          private object()
           { }
 }
