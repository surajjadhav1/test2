import java.util.*;

record Item( String name, String brand){}

record customer( double id , double purchase, int rating) implements comparable <customer){

public int compareTo(customer that){

    return id.comapreTo(that.id);
}

class shop
{
   public static Item[] getItems(){
	   return new Item []{

         new Item( "cpu", "Intel"),
         new Item( "mouse", "iball"),
         new Item( "Keyboard","Samsung"),
         new Item( "pendrive", "Hp"),
         new Item( "desktop", "Intel"),
         new Item( "sound System","lenovo"),
         new Item( "mouse", "Intel"),
         new Item( "cpu", "Intel")

	   };
   }


public static Collection<customer> getcustomers(){
   var customers = new ArrayList < customers>();

     customers.add(new customer("Mahesh" , 10000, 3));
     customers.add(new customer("rahul" ,  15000, 2));
     customers.add(new customer("nisha" , 25000, 1));
     customers.add(new customer("baju" , 35000, 4));
     customers.add(new customer("kalpesh" , 45000, 5));
     customers.add(new customer("sahil" , 65000, 6));
     customers.add(new customer("rushikesh" , 70000, 7));
     customers.add(new customer("Abhisheak" , 75000,8));
     customers.add(new customer("pankaj" , 90000, 10));

	
     
     return customers;
	}
}
