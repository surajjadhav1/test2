package Bank;

final class PersonalLoan extends Loan implements Taxation{

	public double GetRate(){
		double rate = 0;

		if(Getprinciple()<=500000){	
	    		return rate = 15;
      		}
         	else
			return rate = 16;
	}
	public double Tax(){
		return principle > 2000000 ? 0.9 * principle : principle ;
	}
/*
	public GetTax()
	if(super.Getprinciple<= 500000){
		return Getprinciple () *12/100;
	else    
	      	return Getprinciple() * 18/100;
	}
	*/
}

