package Bank .*;

public class Programe

{

     

	public static void main (String[] args){

		double p = Double.parseDouble(args[0]);
		double n = Double.parseDouble(args[1]);
		double rate = Double.parseDouble(args[2]);
	//	double   = Double.parseDouble(args[3]);

             

		System.out.println("Enter Principle Amount :");
                System.out.println("Enter The Period :");

               var s = new Personal(double p, double n);
	       s.PersonalLoan;

	       var l = new Home(double p, double n ,double rate)
               l.HomeLoan;
              System.out.printf("The PersonalLoan is %.2f%n",());

              System.out.printf("The HomeLoan is %.2f%n",());
	       


