package Bank;

public class HomeLoan extends Loan implements Discountable{
		
	public static  double GetRate(){

		double rate = 0;
		if(super.Getprinciple() <= 2000000)
		 {
			 return rate = 10;
		 }
		else
			return rate = 11;
	}

	public static double Discount (){
		return principle > 500000 ? Loan.getEMI() * 0.95 : Loan.getEMI(); 
	}

	public GetDiscount(){

         if (super.Getprinciple()<=2000000)
		 return GetEMI() * 2/100;
	 else
                return  GetEMI() * 5/100;
	}



}
