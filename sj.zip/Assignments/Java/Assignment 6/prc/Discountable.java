package Bank;

interface Discountable{
	public double Discount();
}
