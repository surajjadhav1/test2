package Bank;

abstract class Loan 
{

	public  static double principle;
	public  static double period;

	public Loan (double p , double n){
		principle = p;
		period = n;
	}

	public Loan(){
		principle= 10000;
		period = 3;
	}

	public double Getprinciple(){
		return principle;
	}

	public void Setprinciple( double p){
		principle = p;

	}

	public double Getperiod(){
		return period;
	}

	public void Setperiod(double n){
		period = n;
	}
        public abstract double GetDiscount(); 

        public abstract double Gettax() = 0;


	public  abstract double GetRate() = 0;

       // public static double GetRate();

	public static double getEMI(){
	  	double  r = GetRate();
		double EMI = (principle * (1 + r * period/100)/ (12 * period));
		return EMI;
     	 }


}



