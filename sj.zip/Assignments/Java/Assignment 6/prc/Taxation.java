package Bank;

interface Taxation{
	public abstract double Tax();
}
