#include<cstdio>
#include"investment.h"

int main(void)
{
	double 	principle;
	int 	duration,opt;

	printf("Enter the amount and duration : ");
	scanf("%lf%d",&principle,&duration);

	Investment inv;
	inv.GetInv(principle,duration);

	printf("Enter your choice of interest : \n1.Simple Interest \n2.Compound Interest\n");
	scanf("%d",&opt);

	inv.GetInt(opt);
}
	
