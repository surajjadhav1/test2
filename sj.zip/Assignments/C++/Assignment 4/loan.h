namespace Bank
{
	class Loan
	{
	public:
		double 	GetPrinciple();

		void	SetPrinciple(double p);
		
		float	GetPeriod();
	
		void	SetPeriod(float n);

		virtual	float GetRate() = 0;

		double	GetEMI();
		
		
	private:
		double	principle;
		float	period;
	};

	class PersonalLoan : public Loan
	{
	public:
	   	PersonalLoan(double pri, float per);
		float GetRate();
	};

       	class HomeLoan : public Loan
	{
	public:
	   	HomeLoan(double pri, float per);
		float GetRate();

       	};

}
