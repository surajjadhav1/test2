#include<iostream>
#include "loan2.h"

using namespace std;

double Compute(Loan& L)
{
	return L.GetEMI();
}

int main(void)
{
	double 	principle;
	float	period;
	int	choice;

	cout 	<<"Enter Principle and period"
		<<endl;
	cin 	>> principle>>period;
	

	cout 	<< "Enter the choice for type of loan \n1.Personal Loan \n2.Home Loan"
	       	<< endl;
	cin	>> choice;


	if(choice==1)
	{
			HomeLoan p(principle,period);
			
		//	cout<<"Principle : "<<Bank::Loan::GetPrinciple()<<endl;

		//	cout<<"Period : "<<Bank::Loan::GetPeriod()<<endl;

			cout	<<"The EMI for choosen type of loan for principle "
				<< principle 
				<<" and period of "
				<<period
				<<"years is "
				<<Compute(p)
				<<endl;
	}
	else
	{
			PersonalLoan p(principle,period);
			//p.SetPrinciple(principle);
			//p.SetPeriod(period);
		//	cout<<"Principle : "<<Bank::Loan::GetPrinciple()<<endl;

		//	cout<<"Period : "<<Bank::Loan::GetPeriod()<<endl;

			cout	<<"The EMI for chosen type of loan for principle Rs"
				<< principle 
				<<" and period of "
				<<period
				<<" years is "
				<<Compute(p)
				<<endl;
	}

}
