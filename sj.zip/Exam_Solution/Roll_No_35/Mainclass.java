package MyUtil.*;
 

    class Mainclass{
         
	   public static void main(String[]args){

		  int number = Integer.parseInt(args[0]);

		   var p = new mynumber( int n);
		       p.
	       	 System.out.println("Check for Number Even/odd :");

	    if (MathUtil.isEven() {
            System.out.printf("the number %d is even %n" , number);
            }
	    else {
		    System.out.printf("Number is %d is Odd%n", number);
	    }
           
	    System.out.println("Check for Number Positive/Negative :");

	    if (MathUtil.isPositve()) {
            System.out.printf("the number %d is even %n" , number);
            }
	    else{
		    System.out.printf("Number is %d is Negative%n", number);
	    }

	    System.out.println("Check number for Prime");
            
	    if (MathUtil.isPrime()){
            System.out.printf("the number %d is isPrime%n",number);
            }
	    else{
		    System.out.printf("Number is  %d not prime%n", number)
	    }

	   }
	   

          	    
	   

          	    
	   

          	    
	   

          	    
	   

          	    
	   

          	    
	   

          	    
	   
	   

          	    
	   
	   
	   
	   

          	    

          	    

          	    

          	    

          	    

          	    
