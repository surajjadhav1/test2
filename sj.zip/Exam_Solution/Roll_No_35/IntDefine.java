package MathUtil;

  public interface IntDefine{
	  public  int math()
  }


