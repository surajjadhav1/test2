
namespace Results;

public class Student
{
     
     public int Id {get;set;}
    public string name{get;set;}
    public Date date {get;set;}

    public float []marks {get;set;}


    public Student (int Id ,string name, Date date, float []marks)
{
    this.Id= Id;
    this.name=name;
    this.date=date;
    this.marks= marks;
}
}