
namespace Results;

public class Date
{

//Member function or instance field
public int day;
public int month;
public double year;

 //parameterized constructor
public Date( int d ,int m, double y)
{
    day  = d;
    month= m;
    year = y;
}
 //parameter-less constructor
public Date() : this(15, 4,2022)
{
}

 public int Dates
         
        {
            get { return day; }
            set { day = value; }
        }
        public int Month
        {
            get { return month; }
            set { month = value; }
        }

        public double Year
        {
            get { return year; }
            set { year = value; }

        }


}
