﻿
using Results;
float [] marks = new float[]{78,67,82};

Date date=new Date(07,05,1995);

Student st= new Student(105,"Rahul", date, marks);

Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}",st.Id,st.name,st.date.day,st.date.month,st.date.year);
Console.WriteLine($"Marks of Student is :{st.marks[0]}\t{st.marks[1]}\t{st.marks[2]}");




