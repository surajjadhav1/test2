package MathUtil;


 public class MyInteger{
      
         private static int num;

         //initialize constructor
	 public  MyInteger(int num){

		 num = n;
	 }

	 //default constructor
	 public  MyInteger() {

             num = 0;
	 }

	 public static boolean isEven(){
           if(num % 2== 0)
		   return true;
	   return false;
	 }

        public static boolean isOdd(){

		if(num % 2 != 0)
			return true;
		return false;
	}

	public static boolean isPositive(){
		if(num >= 0)
		//System.out.println("Number is Positive :");	
                 return true;
		return false;
	}
	public static boolean isNegative(){
	        if(num <= 0 )
		// System.out.println("Number is  negative :");	
		 return true;
		return false;
	}
       public static boolean isZero(){

	       if (num ==0)
		       return true;
	       return false;
       }

 }


		





