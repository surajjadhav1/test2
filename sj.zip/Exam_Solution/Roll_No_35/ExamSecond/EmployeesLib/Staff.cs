
namespace EmployeeLib;

//a class defined with abstract modifier cannot be
//activated, it can only be used as a base class
public abstract class Staff

{

    
    //an instance method defined with abstract modifier
    //is pure and it must be overridden in a non-abstract
    //derived class
    public string name{get;set;}

    public string address{get;set;}


    //parameterized constructor
    public Staff(string name,string address)
    {
        this.name = name;
        this.address=address;
    }

    public Staff():this( "Mahesh", "Mumbai")
    {
    }
}