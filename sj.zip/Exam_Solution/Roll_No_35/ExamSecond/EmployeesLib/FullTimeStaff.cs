
namespace EmployeeLib;

public class FulltimeStaff : Staff

{
    public string Department{get;set;}
    public double Salary{get;set;}
    public FulltimeStaff( string name ,string address ,string Department,double Salary):base(name ,address)

    {
        this.Department = Department;
        this.Salary = Salary;

    }

    public FulltimeStaff():this("Mahesh" ,"Mumbai" ,"Design" , 45000)

    {

    }

    public void Display()

    {
        
    }
}