﻿

using EmployeeLib;
//C# supports top-level statements which are copied by the
//compiler into the Main method of the auto-generated Program class

public static void Main(string[] args)
{
Console.WriteLine("Choice  1 for Fulltimestaff \t Choice 2 for ParttimeStaff ");

int p= int.Parse(Console.ReadLine());

switch(p)
{
    case 1:

           ICollection<FulltimeStaff> Staff = AllStaff.GetFullStaff();
           foreach(var entry in Staff)
           entry.Display();
           break;
    case 2:
    
             ICollection<PartTimeStaff>pstaff=AllStaff.GetPartStaff();

             foreach(var entry in pstaff)
             entry.Display();
            break;
}

 class AllStaff
 {

    public static  ICollection<FulltimeStaff> GetFullStaff()
    {
        var staff= new List<FulltimeStaff>();

        staff.Add(new FulltimeStaff("Rahul" ,"Pune","Account",45000));
        staff.Add(new FulltimeStaff("Mahesh" ,"Kolapur","Account",40000));
        staff.Add(new FulltimeStaff("Kalpesh","Bihar","Account",35000));
        staff.Add(new FulltimeStaff("Sahil" ,"Mumbai","Account",45000));
        staff.Add(new FulltimeStaff("Rakesh" ,"Manipur","Account",47000));
        return staff;
    }

    public static class ICollection<PartTimeStaff> GetPartStaff()
{
    var Staff = new List<PartTimeStaff>();
        Staff.Add(new PartTimeStaff("Rahul" ,"Pune",180,150));
        Staff.Add(new PartTimeStaff("Rohan" ,"Pune",155,151));
        Staff.Add(new PartTimeStaff("Ashish" ,"Pune",180,185));
        Staff.Add(new PartTimeStaff("Rahul" ,"Pune",182,156));
      
       return Staff;

}

 }

}

