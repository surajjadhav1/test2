
namespace EmployeeLib;

public class PartTimeStaff :Staff

{
    public int NoOfHour{get;set;}
    public int RatePerHour{get;set;}
    public PartTimeStaff(string name , string address,int NoOfHour,int RatePerHour):base(name,address)
    {
        this.NoOfHour=NoOfHour;
        this.RatePerHour=RatePerHour;
    }
    public PartTimeStaff(): this("Mahesh","Mumbai",110,120)
    {

    }

    public void Display()
    {

    }
}