package MathUtil;


  final public class MyNumber extends MyInteger implements IntDefine{
	   
      
	   public abstract class Math(){ 
	      public MyNumber(int n){
		     super(n); 
                 }



                public static boolean isPrime(){

			if(num <=1)
				return false;
			if(num ==2)
				return true;
			if(num ==3)
				return true;
			if(isEven())
				return false;
			if (isOdd())
				for(int i =3; i*i<=num;i += 2)
				{
					if num( % i == 0)
						return false;
				}
			return true;
		}

		public static int CountPrime(){

			int term , count = 0;

			for(term =1; count <=num; count++)
			{

			boolean i;
		        i = isPrime();
		int a = Integer.parseInt(i);
	        int sum = sum + a;
	        return sum;}	
                  
	   }
