ls
using Advertisement;

class Program
{

    public static double BannerPrice(Banner info, int copies)
    {
        float rate = copies < 5 ? 0.75f : 0.8f;
        return copies * rate * info.Area();
    }

    public static void Main(string[] args)
    {
        float width = float.Parse(args[0]);
        float height = float.Parse(args[1]);

        if(args.Length < 4)
        {
            int copies = int.Parse(args[2]);
            Banner ban = new Banner(width,height);
            Console.WriteLine("The area of given Banner is {0:0.00}",ban.Area());
            Console.WriteLine("The price of given Banner is Rs {0:0.00}",BannerPrice(ban,copies));
        }
        else
        {   
            float radius = float.Parse(args[2]);
            int copies = int.Parse(args[3]);
            CurvedBanner cur = new CurvedBanner(width,height,radius);
            Console.WriteLine("The area of curved banner is {0:0.00}",cur.Area());
            Console.WriteLine("The price of curved banner is Rs {0:0.00}",BannerPrice(cur,copies));
        }
    }
}
