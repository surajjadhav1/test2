namespace Advertisement;
public class CurvedBanner : Banner
{
    private float radius;

    public CurvedBanner() : base()
    {
        radius = 0.1f;
    }

    public CurvedBanner(float w, float h, float r) : base(w,h)
    {
        radius = r;
    }
    

    public override bool Resize(float w, float h)
    {
        base.Resize(w, h);
        radius = 0.2f;
        return true;
    }
    public override double Area()
    {
        return base.Area() - 0.86 * radius * radius;
    }
}