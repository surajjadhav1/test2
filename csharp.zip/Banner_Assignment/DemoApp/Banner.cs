﻿namespace Advertisement;

public class Banner 
{
    private float width;
    private float height;

    public Banner()
    {
        width = 20;
        height = 5;
    }

    public Banner(float w, float h)
    {
        width = w;
        height = h;
    }
    
    public virtual bool Resize(float w, float h)
    {
        if(w>=h)
        {
            width = w;
            height = h;
            return true;
        }
        return false;
    }
    
    public virtual double Area()
    {
        return width * height;
    }
}