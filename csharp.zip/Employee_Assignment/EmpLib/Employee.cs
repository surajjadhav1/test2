﻿namespace Emplib;

public class Employee
{
  
      private int eid;
      private int age;
      private int hours;
      private double rate;

public Employee()
    {
       eid = 4501;
       age = 27;
       hours = 150;
       rate 180;
    }

public Employee(int id ,int ag, int hrs,double r)

    {
        eid   = id;
        age   = ag;
        hours = hrs;
        rate  = r;
    }

public double GetNetIncome()
   {
        int overtime = hours - 180;

        if(overtime>0)

        return hours * rate + overtime;

        else
        return  hours * rate;
   }

public void PrintEmployee()

   {
      //  Console.WriteLine("Employee with id , age , hours netincome concert with {0:0.00} {1:0.00} {2:0.00} {3:0.00}", GetNetIncome(id,age , hours) );

   }




}





