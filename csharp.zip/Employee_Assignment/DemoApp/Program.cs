using EmpLib;
 class EmployeeSalary
 {

      public static void Main(string[]args)

      {
            int id  = int.Parse(args[0]);
            int ag  = int.Parse(args[0]);
            int hrs = int.Parse(args[0]);
            double r= double.Parse(args[0]);

            Employee emp = new Employee(id , ag, hrs, r);

            Console.WriteLine("Employee total GetNetIncome:{0:0.00} , {1:0.00}", emp.GetNetIncome() , emp.);
            
            Console.WriteLine("Employee with id , age , hours netincome concert with {0:0.00} {1:0.00} {2:0.00} {3:0.00}", );

   }





      }
 }

