
namespace BankLib;

sealed public class HomeLoan:Loan
{

    public override double GetRate()
    {
        if (principle<=2000000)

        {
            return 10;
        }
        else

          return 11;
    }

    public double Discount()
   {

     return (principle >500000? base.GetEMI() *0.95 :base.GetEMI());
   }

   public  double GetDiscount()
   {
    if(principle<=2000000)
     return (GetEMI()*2/100);
     else
     return GetEMI()*5/100;

   }
}


