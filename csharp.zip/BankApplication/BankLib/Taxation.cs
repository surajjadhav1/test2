namespace BankLib;

interface Taxation 
{
    public abstract double Tax();
}