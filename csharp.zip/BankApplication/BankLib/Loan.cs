﻿namespace BankLib;
public abstract class Loan

{
       public static double principle;
       public static double period;
    public Loan(double princi, double peri)

    {
        principle = princi;
         period   = peri;
    }

    public Loan():this(25000,5)
    {
    }

    public double Principle
    {
       get
       {
          return principle;
       }
       set
       {
          principle = value;
       }
    }

    public double Period
    {
        get
        {
            return period;
        }
        set
        {
            period = value;
        }
    }

    //public abstract double GetDiscount();

    //public abstract double GetTax();

    public abstract  double GetRate();

    //public abstract double Getprinciple();

    public double GetEMI()
 {

    double r = GetRate();

    double GetEMI =(principle * (1 + r * period /100)/(12 * period));

    return GetEMI;
 }

 }

