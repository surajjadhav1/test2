
namespace hosLib;

public class InhousePatient:Patient
{
   private double discount;

   public InhousePatient(): base(404 ,12,15)

   {
        discount = 0.5f;
   }

   
  public InhousePatient(int pid, int bedType , int days , double dis) :base(pid , bedType , days)
   {
       discount = dis;
   }

public override double getBillAmount()
{
     return base.getBillAmount() *discount;
} 






}