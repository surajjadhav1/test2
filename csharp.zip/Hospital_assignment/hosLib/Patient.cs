﻿namespace hosLib;
public class Patient
{
   private static int Patid;
   private static int BedType;
   private static int  Days;

   public Patient():this(404 , 12 ,15)
   {
   } 
    public Patient(int pid, int bedType , int days)
 
   {
        Patid   = pid;
        BedType = bedType;
        Days    = days;
   }

   public int Pid
   {
      get
       {
          return Patid; 
       }
      set
       {
         Patid = value;
       }
   }
 public int bedType
   {
      get
       {
          return BedType; 
       }
      set
       {
         BedType = value;
       }
   }

 public int days
   {
      get
       {
          return Days; 
       }
      set
       {
         Days = value;
       }
   }

   public double getPricePerDays()
       {
       double rate = 0;
       if(BedType == 1)
         return 500;
       if(BedType == 2)
         return 350;
      if(BedType == 3)
         return 200;
       return rate;
   }
     
  public virtual double getBillAmount()
  {
   double amount;
    return amount = getPricePerDays()* Days;
  }


}
