﻿using hosLib;

class Program
{
    public static void Main(string []args)
{
    int Pid = int.Parse(args[0]);
    int bType = int.Parse(args[1]);
    int days = int.Parse(args[2]);
    //double dis =double.Parse(args[3]); 
     if(args.Length>3)
  {
    Console.WriteLine("Bill Amount For Patient:");
    Patient p = new Patient(Pid,bType,days);
    Console.WriteLine(" Bill Amount is Rs {0}", p.getBillAmount());
  }
    else
  {
      Console.WriteLine("Bill Amount For InhousePatient:");
      InhousePatient q= new InhousePatient(Pid,bType,days,0.7);
      Console.WriteLine(" Bill Amount is Rs {0}", q.getBillAmount());
  }




}
}