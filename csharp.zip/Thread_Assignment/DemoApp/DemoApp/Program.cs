﻿
class Program
{
    public static int i;

static Object obj = new Object();
    private static Thread p1;
     private static Thread p2;
    static LinkedList<int> a = new LinkedList<int>();
    static void Main(string[] args)
    {
        for (int i = 0; i < 10; ++i)
        {
            a.AddLast(i);
        }

        p1 = new Thread(EvenNumber);
        p2 = new Thread(OddNumber);
        p1.Name = "Odd";
        p2.Name = "Even";
        p1.Start();
        p2.Start();
        p1.Join();
        p2.Join();

        Console.WriteLine("Done!");
        Console.Read();
    }

	private static void EvenNumber()
    {
		if(i % 2 == 0)
			
            Console.WriteLine("Thread<{0}> has accepted Even number<{1}> for ", Thread.CurrentThread.ManagedThreadId, i);
	}

	private static void OddNumber()
    {
		if(i % 2 != 0)
			
           Console.WriteLine("Thread<{1}> has accepted Oddnumber<{1}> ", Thread.CurrentThread.ManagedThreadId,i);
	
	}

}  