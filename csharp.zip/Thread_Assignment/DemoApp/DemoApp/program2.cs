using System.Runtime.CompilerServices;

class Program
{
class Number
 {
public void OddNumber(int num)
   {
        for(int i=1;i<=num;++i){
        lock(typeof(Number)){
        if(i % 2 != 0)
    {
         Console.WriteLine("Thread<{0}>:{1} ", Thread.CurrentThread.ManagedThreadId, i);
         Monitor.Wait(typeof(Number));
         Monitor.Pulse(typeof(Number));
    
    }
  }
}
}

[MethodImpl(MethodImplOptions.Synchronized)]
public void EvenNumber(int num)
{
  
   
    for(int i=0;i<=num;++i)
{
    lock(typeof(Number))
    {
      if(i% 2==0)
      {
       Console.WriteLine("EvenNumber<{0}>:{1}", Thread.CurrentThread.ManagedThreadId, i);
       Monitor.Pulse(typeof(Number));
       Monitor.Wait(typeof(Number));
      }
    }
}
   
   }
}

public static void Main(string[]args)
{
int a = int.Parse(args[0]);

var number = new Number();

Thread child= new Thread(() => 
{
    number.EvenNumber(a);
});
child.Start();
number.OddNumber(a);


}

}