﻿class MathOperation
{

   public static void Main(string[]args)

   {
      int  a= int.Parse(args[0]);

      Console.WriteLine("Checking For IsOdd or IsEven Number");

      //mathutil m = new mathutil(a);
      if(MathUtil.IsEven(a))
      {
         Console.WriteLine("Number is Even" );
      }
      else
      {
         Console.WriteLine("Number is Odd " );
      }
   
         Console.WriteLine("Checking For Prime Number");

      if(MathUtil.IsPrime(a))
      {
         Console.WriteLine("Number is Prime ");
      }
      else
      {
         Console.WriteLine("Number is NotPrime " );
      }

   
      
      Console.WriteLine("Number is reverse {0}", MathUtil.reverseNumber(a));
      
   }  

}
